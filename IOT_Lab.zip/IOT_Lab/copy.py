import urllib.request
urllib.request.urlretrieve("https://tinyurl.com/iootttt","app.zip")